package com.bnn.setpassword.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bnn.forgotpasswordvalidattion.Dao.ForgetPasswordValidationDao;
import com.bnn.forgotpasswordvalidattion.model.ForgotPasswordValidation;

/**
 * Servlet implementation class SetpasswordServlet
 */
@WebServlet("/SetpasswordServlet")
public class SetpasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	  private ForgetPasswordValidationDao ForPassValDao;
      
      public void init() {
  		ForPassValDao =new ForgetPasswordValidationDao();
  	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetpasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String password = request.getParameter("password");
		String newpassword = request.getParameter("newpassword");
		ForgotPasswordValidation FPvalidation = new ForgotPasswordValidation();
		FPvalidation.setEmail(password);
		FPvalidation.setUser_name(newpassword);
		
		try {
			if (ForPassValDao.validate(FPvalidation)) {
				//HttpSession session = request.getSession();
				// session.setAttribute("username",username);
				response.sendRedirect("setpassword.jsp");
			} else {
				HttpSession session = request.getSession();
				//session.setAttribute("user", username);
				response.sendRedirect("ForgetPasswordValidation.jsp");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


}
