package com.bnn.registration.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnn.registration.Dao.Userdao;
import com.bnn.registration.model.Users;

/**
 * Servlet implementation class userservlet
 */
@WebServlet("/userservlet")
public class userservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Userdao userdao = new Userdao();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
    public userservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher disp = request.getRequestDispatcher("userregister.jsp");
		disp.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("first_name");
        String Address = request.getParameter("address");
        String Email = request.getParameter("email");
        String User_name = request.getParameter("user_name");
        String Password = request.getParameter("password");
        String Registration_date = request.getParameter("registration_date");

        Users user = new Users();
        user.setFirst_name(firstName);
        user.setAddress(Address);
        user.setEmail(Email);
        user.setUser_name(User_name);
        user.setPassword(Password);
        user.setRegistration_date(Registration_date);
        
        
        try {
			userdao.registerEmployee(user);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        RequestDispatcher disp = request.getRequestDispatcher("userdetails.jsp");
		disp.forward(request, response);
	}

}
