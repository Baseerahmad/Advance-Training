package com.bnn;
import java.util.*;
public class FirstRepetingNumberIn_Array {
	 static void printFirstRepeating(int arr[])
	    {
	        int min = -1;
	 
	        HashSet<Integer> set = new HashSet<>();
	        for (int i=arr.length-1; i>=0; i--)
	        {
	            if (set.contains(arr[i]))
	                min = i;
	            else 
	                set.add(arr[i]);
	        }
	        if (min != -1)
	          System.out.println("The first repeating element is " + arr[min]);
	        else
	          System.out.println("There are no repeating elements");
	    }
	    public static void main (String[] args) throws java.lang.Exception
	    {
	    	 Scanner sc = new Scanner(System.in);
	    	 System.out.println("Enter length of array : ");
	    	int[] arr = new int[sc.nextInt()];
	        System.out.println("enter array values : ");
	        for (int i = 0; i < arr.length; i++) {
	            arr[i] = sc.nextInt();
	         }
	        System.out.println("The given sting is "+Arrays.toString(arr));

	     //	        int arr[] = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
//	        
//	        int arr1[] = { 1, 2, 3, 10, 6, 4, 3, 7, 10};
//	        printFirstRepeating(arr);
//	        printFirstRepeating(arr1);
	    	printFirstRepeating(arr);
	    }
}

/*
Enter length of array : 
7
enter array values : 
2
5
3
4
2
3
7
The given sting is [2, 5, 3, 4, 2, 3, 7]
The first repeating element is 2
*/
