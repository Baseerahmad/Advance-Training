package com.bnn;

import java.util.*;

public class Finding_nthNode {
	 public static void main(String a[]) {

		    Node firstNode = new Node(1);
		    Node secondNode = new Node(2);
		    Node thirdNode = new Node(3);
		    Node fourthNode = new Node(4);
		    Node fifthNode = new Node(5);
		    Node sixthNode = new Node(6);
		    Node seventhNode = new Node(7);
		    Node eighthNode = new Node(8);
		    Node ninthNode = new Node(9);
		    
		    
		    Node head = firstNode;
		    head.setNext(secondNode);
		    secondNode.setNext(thirdNode);
		    thirdNode.setNext(fourthNode);
		    fourthNode.setNext(fifthNode);
		    fifthNode.setNext(sixthNode);
		    sixthNode.setNext(seventhNode);
		    seventhNode.setNext(eighthNode);
		    eighthNode.setNext(ninthNode);

		    
		    Scanner sc = new Scanner(System.in);
		    System.out.println("Enter the nth node from the end of Linked List ");
		   int elem = sc.nextInt();
		    System.out.println(elem+"nd element from end in linked list is : " + getNthNodeFromEnd(head, elem));

		 
		    
		   
		    
		 


		  }

		  public static Node getNthNodeFromEnd(Node head, int n) {
		    Node fast = head;
		    Node slow = head;

		    for (int i = 1; i <= n; i++) {
		      fast = fast.getNextNode();
		    }

		    while (fast != null) {
		      fast = fast.getNextNode();
		      slow = slow.getNextNode();
		    }

		    return slow;

		  }
		}

		class Node {

		  private Node next;

		  private int data;

		  public Node(int data) {
		    this.data = data;

		  }

		  public int getData() {
		    return data;

		  }

		  public Node getNextNode() {
		    return next;
		  }

		  public void setNext(Node next) {
		    this.next = next;
		  }

		  @Override
		  public String toString() {
		    return String.format("%d", data);

		  }
}

		/*
		output
Enter the nth node from the end of Linked List 
2
2nd element from end in linked list is : 8
*/