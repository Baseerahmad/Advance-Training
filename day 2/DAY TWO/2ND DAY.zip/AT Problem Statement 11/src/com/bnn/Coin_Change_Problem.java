package com.bnn;

import java.util.Scanner;
import java.util.Vector;

public class Coin_Change_Problem {
	 // All denominations of Indian Currency 
    static int deno[] = {1, 2, 5, 10, 20, 
    50, 100, 500, 2000};
    static int n = deno.length;
  
    static void findMin(int V)
    {
        // Initialize result 
        Vector<Integer> ans = new Vector<>();
  
        // Traverse through all denomination 
        for (int i = n - 1; i >= 0; i--)
        {
            // Find denominations 
            while (V >= deno[i]) 
            {
                V -= deno[i];
                ans.add(deno[i]);
            }
        }
  
        // Print result 
        for (int i = 0; i < ans.size(); i++)
        {
            System.out.print(
                " Rs"+ ans.elementAt(i)+"*1");
        }
    }
  
    // Driver code 
    public static void main(String[] args) 
    {
//        int n = 93;
        Scanner sc = new  Scanner(System.in);
        System.out.println("Enter the amount to get the change");
        int n = sc.nextInt();
        System.out.println(
            "Following is minimal number "
            +"of change reqird for Rs " + n + ": ");
        findMin(n);
    }
}
/*
output
Enter the amount to get the change
2515
Following is minimal number of change reqird for Rs 2515: 
 Rs2000*1 Rs500*1 Rs10*1 Rs5*1
 ****
Enter the amount to get the change
556
Following is minimal number of change reqird for Rs 556: 
 Rs500*1 Rs50*1 Rs5*1 Rs1*1
*/